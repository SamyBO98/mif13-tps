package fr.univlyon1.mif13.tp1.model;

public class UserModel {

    private String login;
    private String password;

    public UserModel(){

    }

    public String getLogin() {
        return login;
    }

    public String getPassword() {
        return password;
    }
}
