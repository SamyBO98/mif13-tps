package fr.univlyon1.mif13.tp1.exception;

public class MissingArgumentsException extends RuntimeException {

    public MissingArgumentsException(){
        super("Missing arguments");
    }

}
