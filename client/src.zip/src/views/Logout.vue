<template>
  <div class="logout">
    <Logout />
  </div>
</template>

<script>
// @ is an alias to /src
import Logout from "@/components/Logout.vue";

export default {
  name: "logout",
  components: {
    Logout,
  },
};
</script>
