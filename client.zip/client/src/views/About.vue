<template>
  <div class="main-title">
    <h1>About page</h1>
  </div>
</template>
